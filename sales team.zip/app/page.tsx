"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import TaskViewDialog from "@/components/task-view-dialog"
import TaskEditDialog from "@/components/task-edit-dialog"
import TaskDeleteDialog from "@/components/task-delete-dialog"
import SummaryInsights from "@/components/summary-insights"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/hooks/use-toast"

interface Task {
  id: string
  title: string
  revenue: number
  timeTaken: number
  priority: "High" | "Medium" | "Low"
  status: "Pending" | "In Progress" | "Completed"
  notes: string
  createdAt: number
}

export default function TaskApp() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [viewingTask, setViewingTask] = useState<Task | null>(null)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [deletingTask, setDeletingTask] = useState<Task | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("All")
  const [filterPriority, setFilterPriority] = useState<string>("All")
  const [lastDeletedTask, setLastDeletedTask] = useState<Task | null>(null)
  const [showUndoSnackbar, setShowUndoSnackbar] = useState(false)
  const [undoTimeout, setUndoTimeout] = useState<NodeJS.Timeout | null>(null)
  const { toast } = useToast()
  const [hasInitialized, setHasInitialized] = useState(false)

  useEffect(() => {
    if (hasInitialized) return

    const loadTasks = () => {
      console.log("[v0] Loading tasks from localStorage")
      try {
        const stored = localStorage.getItem("tasks")
        if (stored) {
          const parsed = JSON.parse(stored)
          setTasks(parsed)
        }
      } catch (error) {
        console.error("[v0] Error loading tasks:", error)
      }
    }

    loadTasks()
    setHasInitialized(true)
  }, [hasInitialized])

  // Calculate ROI with validation
  const calculateROI = (revenue: number, timeTaken: number): number => {
    if (!revenue || !timeTaken || timeTaken === 0) {
      return 0
    }
    const roi = revenue / timeTaken
    return Math.round(roi * 100) / 100
  }

  // Save tasks to localStorage
  useEffect(() => {
    if (tasks.length > 0 || hasInitialized) {
      localStorage.setItem("tasks", JSON.stringify(tasks))
    }
  }, [tasks, hasInitialized])

  const getSortedTasks = useCallback(
    (tasksToSort: Task[]): Task[] => {
      const filtered = tasksToSort.filter((task) => {
        const matchesSearch =
          task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          task.notes.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesStatus = filterStatus === "All" || task.status === filterStatus
        const matchesPriority = filterPriority === "All" || task.priority === filterPriority
        return matchesSearch && matchesStatus && matchesPriority
      })

      return filtered.sort((a, b) => {
        // Primary: Sort by ROI descending
        const roiA = calculateROI(a.revenue, a.timeTaken)
        const roiB = calculateROI(b.revenue, b.timeTaken)
        if (roiA !== roiB) {
          return roiB - roiA
        }

        // Secondary: Sort by priority
        const priorityOrder = { High: 3, Medium: 2, Low: 1 }
        if (a.priority !== b.priority) {
          return priorityOrder[b.priority] - priorityOrder[a.priority]
        }

        // Tie-breaker: Sort by title alphabetically, then by createdAt descending (newer first)
        if (a.title.toLowerCase() !== b.title.toLowerCase()) {
          return a.title.toLowerCase().localeCompare(b.title.toLowerCase())
        }

        return b.createdAt - a.createdAt
      })
    },
    [searchTerm, filterStatus, filterPriority],
  )

  const sortedTasks = getSortedTasks(tasks)

  const handleAddTask = () => {
    const newTask: Task = {
      id: Date.now().toString(),
      title: "New Task",
      revenue: 0,
      timeTaken: 1,
      priority: "Medium",
      status: "Pending",
      notes: "",
      createdAt: Date.now(),
    }
    setEditingTask(newTask)
  }

  const handleSaveTask = (task: Task) => {
    if (task.id && tasks.some((t) => t.id === task.id)) {
      setTasks(tasks.map((t) => (t.id === task.id ? task : t)))
      toast({ description: "Task updated successfully" })
    } else {
      setTasks([...tasks, task])
      toast({ description: "Task created successfully" })
    }
    setEditingTask(null)
  }

  const handleDeleteTask = () => {
    if (!deletingTask) return

    setLastDeletedTask(deletingTask)
    setTasks(tasks.filter((t) => t.id !== deletingTask.id))
    setDeletingTask(null)
    setShowUndoSnackbar(true)

    // Clear previous timeout
    if (undoTimeout) clearTimeout(undoTimeout)

    // Set new timeout - auto-close after 5 seconds
    const timeout = setTimeout(() => {
      setShowUndoSnackbar(false)
      setLastDeletedTask(null) // BUG 2: Clear deleted task when snackbar closes
    }, 5000)

    setUndoTimeout(timeout)

    toast({ description: "Task deleted" })
  }

  const handleUndo = () => {
    if (lastDeletedTask) {
      setTasks([...tasks, lastDeletedTask])
      setLastDeletedTask(null)
      setShowUndoSnackbar(false)
      if (undoTimeout) clearTimeout(undoTimeout)
      toast({ description: "Task restored" })
    }
  }

  const handleCloseSnackbar = () => {
    setShowUndoSnackbar(false)
    setLastDeletedTask(null) // BUG 2: Clear deleted task when snackbar manually closes
    if (undoTimeout) clearTimeout(undoTimeout)
  }

  const handleExportCSV = () => {
    const headers = ["Title", "Revenue", "Time Taken", "ROI", "Priority", "Status", "Notes"]
    const rows = tasks.map((task) => [
      task.title,
      task.revenue,
      task.timeTaken,
      calculateROI(task.revenue, task.timeTaken),
      task.priority,
      task.status,
      task.notes,
    ])

    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `tasks-${Date.now()}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      const csv = e.target?.result as string
      const lines = csv.split("\n")
      const headers = lines[0].split(",").map((h) => h.replace(/"/g, ""))

      const importedTasks: Task[] = lines
        .slice(1)
        .filter((line) => line.trim())
        .map((line) => {
          const cells = line.split(",").map((c) => c.replace(/"/g, ""))
          return {
            id: Date.now().toString() + Math.random(),
            title: cells[0] || "Imported Task",
            revenue: Number.parseFloat(cells[1]) || 0,
            timeTaken: Number.parseFloat(cells[2]) || 1,
            priority: (cells[4] as "High" | "Medium" | "Low") || "Medium",
            status: (cells[5] as "Pending" | "In Progress" | "Completed") || "Pending",
            notes: cells[6] || "",
            createdAt: Date.now(),
          }
        })

      setTasks([...tasks, ...importedTasks])
      toast({ description: `Imported ${importedTasks.length} tasks` })
    }

    reader.readAsText(file)
    event.target.value = ""
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Task Manager</h1>
            <p className="text-sm text-muted-foreground">Track and manage sales tasks by ROI</p>
          </div>
          <Button onClick={handleAddTask}>+ New Task</Button>
        </div>

        {/* Summary Insights */}
        <SummaryInsights tasks={tasks} calculateROI={calculateROI} />

        {/* Search & Filter */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid gap-4 md:grid-cols-4">
              <Input placeholder="Search tasks..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Status</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger>
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Priority</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleExportCSV} className="flex-1 bg-transparent">
                  Export
                </Button>
                <label className="flex-1">
                  <Button variant="outline" size="sm" className="w-full bg-transparent" asChild>
                    <span>Import</span>
                  </Button>
                  <input type="file" accept=".csv" onChange={handleImportCSV} className="hidden" />
                </label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tasks List */}
        <Card>
          <CardHeader>
            <CardTitle>Tasks ({sortedTasks.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {sortedTasks.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">No tasks yet. Create one to get started!</p>
            ) : (
              <div className="space-y-2">
                {sortedTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex flex-col gap-3 rounded-lg border border-border p-4 hover:bg-accent/5 transition-colors md:flex-row md:items-center md:justify-between"
                  >
                    <div className="flex-1 min-w-0">
                      <h3
                        className="font-semibold text-foreground cursor-pointer hover:underline truncate"
                        onClick={() => setViewingTask(task)}
                      >
                        {task.title}
                      </h3>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <Badge variant="outline">{task.status}</Badge>
                        <Badge
                          variant={
                            task.priority === "High"
                              ? "destructive"
                              : task.priority === "Medium"
                                ? "default"
                                : "secondary"
                          }
                        >
                          {task.priority}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1 text-sm md:text-right md:min-w-fit">
                      <p>
                        Revenue: <span className="font-semibold">${task.revenue.toFixed(2)}</span>
                      </p>
                      <p>
                        ROI:{" "}
                        <span className="font-semibold">
                          {calculateROI(task.revenue, task.timeTaken) === 0
                            ? "—"
                            : calculateROI(task.revenue, task.timeTaken).toFixed(2)}
                        </span>
                      </p>
                    </div>

                    <div className="flex gap-2 md:flex-col">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          setEditingTask(task)
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          setDeletingTask(task)
                        }}
                        className="text-destructive hover:text-destructive"
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Undo Snackbar */}
        {showUndoSnackbar && (
          <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm bg-card border border-border rounded-lg p-4 shadow-lg flex items-center justify-between gap-4">
            <p className="text-sm font-medium text-foreground">Task deleted</p>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={handleUndo}>
                Undo
              </Button>
              <Button variant="ghost" size="sm" onClick={handleCloseSnackbar}>
                Dismiss
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Dialogs */}
      {viewingTask && <TaskViewDialog task={viewingTask} onClose={() => setViewingTask(null)} />}
      {editingTask && (
        <TaskEditDialog task={editingTask} onClose={() => setEditingTask(null)} onSave={handleSaveTask} />
      )}
      {deletingTask && (
        <TaskDeleteDialog task={deletingTask} onClose={() => setDeletingTask(null)} onConfirm={handleDeleteTask} />
      )}

      <Toaster />
    </div>
  )
}

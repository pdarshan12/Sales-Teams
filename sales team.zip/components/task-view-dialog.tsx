"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface Task {
  id: string
  title: string
  revenue: number
  timeTaken: number
  priority: "High" | "Medium" | "Low"
  status: "Pending" | "In Progress" | "Completed"
  notes: string
  createdAt: number
}

interface TaskViewDialogProps {
  task: Task
  onClose: () => void
}

export default function TaskViewDialog({ task, onClose }: TaskViewDialogProps) {
  const roi = task.timeTaken > 0 ? (task.revenue / task.timeTaken).toFixed(2) : "0"

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            {task.title}
            <button onClick={onClose} className="rounded hover:bg-accent p-1 text-lg">
              ✕
            </button>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Revenue</p>
              <p className="text-lg font-semibold">${task.revenue.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Time Taken</p>
              <p className="text-lg font-semibold">{task.timeTaken}h</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">ROI</p>
              <p className="text-lg font-semibold">{roi === "0" ? "—" : roi}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Priority</p>
              <Badge
                className="mt-1"
                variant={
                  task.priority === "High" ? "destructive" : task.priority === "Medium" ? "default" : "secondary"
                }
              >
                {task.priority}
              </Badge>
            </div>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-1">Status</p>
            <Badge variant="outline">{task.status}</Badge>
          </div>

          {task.notes && (
            <div>
              <p className="text-sm text-muted-foreground mb-1">Notes</p>
              <p className="text-sm text-foreground">{task.notes}</p>
            </div>
          )}

          <Button onClick={onClose} className="w-full">
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Task {
  id: string
  title: string
  revenue: number
  timeTaken: number
  priority: "High" | "Medium" | "Low"
  status: "Pending" | "In Progress" | "Completed"
  notes: string
  createdAt: number
}

interface SummaryInsightsProps {
  tasks: Task[]
  calculateROI: (revenue: number, timeTaken: number) => number
}

export default function SummaryInsights({ tasks, calculateROI }: SummaryInsightsProps) {
  const totalRevenue = tasks.reduce((sum, task) => sum + task.revenue, 0)
  const totalTime = tasks.reduce((sum, task) => sum + task.timeTaken, 0)
  const roiValues = tasks.map((task) => calculateROI(task.revenue, task.timeTaken)).filter((roi) => roi > 0)
  const averageROI = roiValues.length > 0 ? (roiValues.reduce((a, b) => a + b, 0) / roiValues.length).toFixed(2) : "0"

  // Performance grade based on average ROI
  const avgROINum = Number.parseFloat(averageROI)
  let grade = "C"
  if (avgROINum >= 100) grade = "A"
  else if (avgROINum >= 50) grade = "B"
  else if (avgROINum >= 20) grade = "C"
  else grade = "D"

  const efficiency = totalTime > 0 ? (totalRevenue / totalTime).toFixed(2) : "0"

  return (
    <div className="grid gap-4 md:grid-cols-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Efficiency</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">${efficiency}</p>
          <p className="text-xs text-muted-foreground mt-1">per hour</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Average ROI</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">{averageROI}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Performance Grade</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold">{grade}</p>
          <p className="text-xs text-muted-foreground mt-1">Based on ROI</p>
        </CardContent>
      </Card>
    </div>
  )
}
